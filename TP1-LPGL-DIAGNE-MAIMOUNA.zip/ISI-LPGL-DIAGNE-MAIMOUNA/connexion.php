<!DOCTYPE html>
<html>
<head>
	<title>Connexion</title>
	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<div class="container well col-md-4 col-md-offset-3 design">
		<div class="panel panel-success">
			<div class="panel-heading">Formulaire de connexion</div>
			<form method="POST" action="AccueilUser.php" action="inscription.php">
				<div class="form-group">
					<input type="email" name="login" class="form-control" placeholder="login">
				</div>
				<div class="form-group">
					<input type="password" name="password" class="form-control" placeholder="Mot de passe">
				</div>

							

				 <div class="form-group" >	
                 
				 	
	  <select>
   <label>Profile</label>
    <option value="'.$Admin.'">Admin </option> 
    <option value="'.$User.'">User </option> 
</select>
</div>
	
				

				<div class="btn-group">
					<a href="inscription.php" class="btn btn-info">Inscription</a>
					<input type="submit" name="valider" value="Valider" class="btn btn-success">
				</div>
			</form>
		</div>
	</div>
</body>
</html>