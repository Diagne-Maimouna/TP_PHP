<!DOCTYPE html>
<html>
<head>
	<title>INSCRIPTION</title>
	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<div class="container well col-md-4 col-md-offset-3 design">
		<div class="panel panel-success">
			<div class="panel-heading">Formulaire d'inscription</div>
			<form method="POST" action="MessageInscription.php">
				<div class="row">
					<div class="form-group col-md-6">
					<input type="text" name="nom" class="form-control" placeholder="Nom">
				</div>
				<div class="form-group col-md-6">
					<input type="text" name="prenom" class="form-control" placeholder="Prenom">
				</div>
				</div>
				<div class="row">
					<div class="form-group col-md-6">
					<input type="email" name="login" class="form-control" placeholder="Email">
				</div>
				<div class="form-group col-md-6">
					<input type="text" name="tel" class="form-control" placeholder="Telephone">
				</div>
				</div>
				<div class="row">
					<div class="form-group col-md-6">
					<input type="text" name="login" class="form-control" placeholder="login">
				</div>
				<div class="form-group col-md-6">
					<input type="password" name="password" class="form-control" placeholder="Mot de passe">
				</div>
				</div>

				<div class="row">
					<div class="btn-group col-md-6 col-md-offset-4">
					<a href="connexion.php" class="btn btn-info">Retour</a>
					<input type="submit" name="valider" value="Valider" class="btn btn-success">
				</div>
				</div>
			</form>
		</div>
	</div>

</body>
</html>