<?php

 if (isset($_POST['valider'])) {
 	extract($_POST);
 	
 	echo 'Bonjour ';
 }