<?php
if (isset($_POST['submit'])) {
  extract($_POST);
  
  echo 'input type="text" name="extract($_name)"';
 }
class FORMULAIRE{
	
		
	
	public function input($name)
	{

          echo $form ->input("name");
      return $this->text('<input type="text"class="form-control" name="' .$name .'" value="'.$this->getValue($name).'">'
  );
  }

    public function submit(){
            return $this->submit('<button type="submit" id="envoyer" class="btn btn-primary">submit</button>');
            return $this -> $form->submit();
            
        }
        public function reset(){
            return $this->reset('<button type="reset" id="effacer" class="btn btn-danger">reset</button>');echo $form->reset();
        }
}