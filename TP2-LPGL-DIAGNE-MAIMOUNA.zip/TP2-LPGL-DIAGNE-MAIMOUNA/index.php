<!DOCTYPE html>
<html>
<head>
	<title>INDEX</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	

</head>

<body background="image/canal-manga-6366.jpg" align="center">


	<div class="container well col-md-4 col-md-offset-3 design" >
		

		<div class="panel panel-success">


			<div class="panel-heading">FORMULAIRE</div>
			<form method="POST" action="personne.php">
				<div class="row">
					<div class="form-group col-md-6">
					<input type="text" name="login" class="function input($name)" placeholder="login">
				</div>
				<div class="form-group col-md-6">
					<input type="password" name="password" class="function input($password)" placeholder="Mot de passe">
				</div>
				</div>


				<div class="row">
					<div class="btn-group col-md-6 col-md-offset-4">
					<input type="reset"  name="reset" value="reset" class="btn btn-danger" class="function reset()">
					<input type="submit"  name="submit" value="submit" class="btn btn-success" class="function submit()">
				</div>
				</div>
				
				
			</form>
		</div>
	</div>

</body>
</html>