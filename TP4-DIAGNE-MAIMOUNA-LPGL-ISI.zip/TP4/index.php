<?php 
	$title = "Connexion";
	include('functions/fonctions.php'); 
	include('functions/constantes.php'); 
	chargerMesClasses();

	$db = new Database();

	if (isset($_POST['connexion'])) {
		extract($_POST);
		echo $_SESSION['login'];
		

		if (notEmpty([$login, $mdp])) {
			$data = $db->userHasBeenExist($login, $mdp);

			
				
		}else{
				message("Login ou mot de passe incorrect <br>");
			}
		
	}

	require('view/connexion.view.php');
?>