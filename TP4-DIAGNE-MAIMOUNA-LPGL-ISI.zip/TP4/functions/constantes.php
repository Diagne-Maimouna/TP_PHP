<?php 

	define("DB_HOST" ,"localhost");
	define("DB_NAME" , "tp4");
	define("USER_NAME" , "root");
	define("PWD" , "");

 ?>