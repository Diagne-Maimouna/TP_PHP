 <!DOCTYPE html>
 <html>
 <head>
 	<title>BLOG</title>
 	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
 	<link rel="stylesheet" type="text/css" href="style/style.css">
 </head>
 <body>