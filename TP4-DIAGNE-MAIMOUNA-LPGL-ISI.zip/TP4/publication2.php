 <!DOCTYPE html>
 <html>
 <head>
  <title>BLOG</title>
  <link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
  <link rel="stylesheet" type="text/css" href="style/style.css">
 </head>
 <body>
		<form action=""   method="post">

           <table border="4" height="150" width="500" align="center" bordercolor="blue" align="center" >
           <td> 
           <p> 
           	
           <div id="formAjoutComment">
        <legend align="center"><u><font color="blue">Ajouter une Publication</font></u> </legend>   
        <form method="post" action="publication.php<?php echo $donnees['id']; ?>" enctype="multipart/form-data">
            
     
       <label form="auteur">TITRE </label>
           <input type=text size=8 placeholder="veuillez entrez le TITRE de la Publication" required> <br>
<label for="Publication" >Votre Publication:</label><br>      
          <textarea name="Publication" id="message" placeholder="Ecrit ta Publication" rows="5" cols="30" ></textarea>
          
           
           
			
		</p>

				<div class="row">
          <div class="btn-group col-md-6 col-md-offset-4">
          <a href="publication.php" class="btn btn-info">ANNULER</a>
          <input type="submit" name="valider" value="Valider" class="btn btn-success">
        </div>
        </div>
				
				
			</td>	
</table>

</body>
</html>