
    	<?php
    		include('partials/_header.php');
      

    	 $texte="This news is for those who want to learn carding🛒  

I have created a private channel where i have already taught how to card with some tools and videos and how to card with them

You are also provided with several cardable sites and methods on how to card them 


I have also provided procedures on how to card with an Android phone 📱in the channel

And a whole lot more all you have to do is read from the beginning if you don't understand anything you ask me to explain further and I will certainly will 😊


I will be adding more tutorials, tools and more methods as time goes on" ;?>
        <fieldset>
      
        <legend align="center"><u><font color="blue">Vos Publications</font></u> </legend>   
		<form action=""   method="post">
           <table border="4" height="150" width="500" align="center" bordercolor="blue">
           <td> 
           <p> 
           	
			<?php

			if(strlen($texte) < 50){
				echo $texte;
			}
			else{

           $first_chaine = substr($texte,0, 50);
           echo $first_chaine;
			
           	 $second_chaine = substr($texte,50);
           	 echo   "<details>
           	 <summary>plus ...</summary>"
           	.$second_chaine."
           </details>";
     }
     ?>
		</p>

				<div class="row">
					<div class="btn-group col-md-6 col-md-offset-4">
					<a href="publication2.php" class="btn btn-info">addpub</a>
				</div>
				</div>
				
				
			</td>	
</table>
</fieldset>
</body>
</html>